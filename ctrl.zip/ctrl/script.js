document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");

    form.addEventListener("submit", function(e) {
        let phone = document.querySelector('input[name="phone"]').value;
        if (isNaN(phone) || phone.length < 10) {
            alert("Please enter a valid phone number!");
            e.preventDefault();
        }
    });
});