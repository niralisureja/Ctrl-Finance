<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];

    // Save the data to a text file (for simplicity)
    $file = fopen("submissions.txt", "a");
    fwrite($file, "$first_name $last_name - $phone - $email\n");
    fclose($file);

    // Display confirmation message
    $thank_you_message = "Thank you! Your consultation request has been submitted.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Landing Page</title>
    
    <!-- Bootstrap 5 CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<!-- Top Header -->
<div class="bg-primary text-white py-2">
    <div class="container d-flex flex-wrap justify-content-between align-items-center">
        <span>📍 252 3rd Floor, Limda Chowk, Rajkot - 360005</span>
        <span>📞 +919375888884 | ✉ contact@fintech.com</span>
        <div>
            <a href="#"><img src="facebook-icon.png" alt="FB" class="mx-2"></a>
            <a href="#"><img src="linkedin-icon.png" alt="LinkedIn" class="mx-2"></a>
            <a href="#"><img src="instagram-icon.png" alt="Instagram" class="mx-2"></a>
        </div>
    </div>
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#">CTRL+F</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link text-dark" href="#">Why Us</a></li>
                <li class="nav-item"><a class="nav-link text-dark" href="#">About Us</a></li>
                <li class="nav-item"><a class="btn btn-warning px-4 text-white fw-bold" href="#">Contact Us</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section py-5" style="background-color: #fef7f4;">
    <div class="container">
        <div class="row align-items-center">
            <!-- Left Text -->
            <div class="col-lg-6 text-center text-lg-start">
                <h6 class="text-primary fw-semibold">Grow Your Business</h6>
                <h1 class="fw-bold">Lorem Ipsum Dolor <br> Sit Your Tagline Goes Here</h1>
                <p class="text-muted">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <a href="#" class="btn btn-primary px-4 py-2 mt-3">Contact Us »</a>
            </div>

            <!-- Right Form -->
            <div class="col-lg-5 offset-lg-1">
                <div class="bg-white p-4 rounded shadow">
                    <h3 class="fw-bold text-center">Book A Consultation</h3>

                    <?php if(isset($thank_you_message)): ?>
                        <div class="alert alert-success text-center"><?php echo $thank_you_message; ?></div>
                    <?php endif; ?>

                    <form action="index.php" method="post">
                        <div class="mb-3">
                            <input type="text" name="first_name" class="form-control" placeholder="First Name*" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" name="last_name" class="form-control" placeholder="Last Name*" required>
                        </div>
                        <div class="mb-3">
                            <input type="tel" name="phone" class="form-control" placeholder="Phone Number*" required>
                        </div>
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control" placeholder="Email Address*" required>
                        </div>
                        <button type="submit" class="btn btn-warning w-100 text-white fw-bold">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
